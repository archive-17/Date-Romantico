# Convite Romântico ❤️

Site estático feito somente com HTML, CSS e JavaScript.

## Arquivos

- `index.html` — estrutura das telas
- `style.css` — visual e animações
- `script.js` — interações e lógica

## Publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie os três arquivos para a raiz do repositório.
3. Abra `Settings` → `Pages`.
4. Em `Build and deployment`, escolha `Deploy from a branch`.
5. Selecione `main` e `/ (root)`.
6. Salve.
7. O GitHub vai gerar o endereço público do site.

## Publicar no Netlify

1. Entre no Netlify.
2. Crie um novo site.
3. Faça upload da pasta do projeto ou conecte o repositório GitHub.
4. Não é necessário configurar build command.
5. A pasta publicada é a própria raiz do projeto.

## Publicar na Vercel

1. Entre na Vercel.
2. `Add New Project`.
3. Importe o repositório GitHub.
4. Como é um site estático, não é necessário framework.
5. Faça o deploy.

## Personalização

Para trocar os textos, abra `index.html`.

Para mudar cores, abra `style.css` e altere as variáveis no começo:

```css
:root {
  --accent: #ff4f91;
  --accent-2: #ff7aaf;
}
```

Para mudar o comportamento do botão NÃO, edite a função `rejectAttempt()` em `script.js`.
