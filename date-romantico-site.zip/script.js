(() => {
  "use strict";

  const app = document.getElementById("app");
  if (!app || app.dataset.initialized === "true") return;
  app.dataset.initialized = "true";

  const screens = {
    landing: document.getElementById("landing"),
    invite: document.getElementById("invite"),
    date: document.getElementById("dateStep"),
    food: document.getElementById("foodStep"),
    final: document.getElementById("finalStep")
  };

  const state = {
    noAttempts: 0,
    date: "",
    time: "",
    food: ""
  };

  function showScreen(name) {
    Object.values(screens).forEach((screen) => {
      screen.classList.remove("active");
    });
    screens[name].classList.add("active");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  // Corações que sobem pelo site.
  const heartContainer = document.querySelector(".hearts");
  const heartSymbols = ["♥", "♡", "❤", "💕"];

  function createHeart() {
    const heart = document.createElement("span");
    heart.className = "heart";
    heart.textContent =
      heartSymbols[Math.floor(Math.random() * heartSymbols.length)];

    heart.style.left = `${Math.random() * 100}%`;
    heart.style.fontSize = `${12 + Math.random() * 24}px`;
    heart.style.animationDuration = `${5 + Math.random() * 6}s`;
    heart.style.animationDelay = `${Math.random() * 0.5}s`;

    heartContainer.appendChild(heart);

    window.setTimeout(() => heart.remove(), 12000);
  }

  // Mantém uma quantidade moderada de corações.
  for (let i = 0; i < 10; i++) {
    window.setTimeout(createHeart, i * 350);
  }
  window.setInterval(createHeart, 850);

  // Tela inicial.
  document.getElementById("openInvite").addEventListener("click", () => {
    showScreen("invite");
  });

  // Botão NÃO.
  const noButton = document.getElementById("noButton");
  const buttonZone = document.getElementById("buttonZone");
  const reaction = document.getElementById("reaction");
  const face = document.getElementById("face");

  const messages = [
    "TEM CERTEZA? 🤨",
    "PENSA BEM... 🥺",
    "POR FAVOR... ❤️",
    "VOCÊ VAI MESMO TENTAR? 😂",
    "ESSA OPÇÃO ESTÁ FUGINDO! 😏",
    "Acho que você quis dizer SIM. 😌"
  ];

  const faces = ["🥺", "😳", "😭", "😂", "😏", "🥰"];

  function moveNoButton() {
    const zoneRect = buttonZone.getBoundingClientRect();
    const buttonRect = noButton.getBoundingClientRect();

    const maxX = Math.max(4, zoneRect.width - buttonRect.width - 4);
    const maxY = Math.max(4, zoneRect.height - buttonRect.height - 4);

    noButton.style.left = `${Math.random() * maxX}px`;
    noButton.style.top = `${Math.random() * maxY}px`;
    noButton.style.right = "auto";
  }

  function rejectAttempt(event) {
    if (event) event.preventDefault();

    state.noAttempts += 1;

    const index = Math.min(state.noAttempts - 1, messages.length - 1);
    reaction.textContent = messages[index];
    face.textContent = faces[index];

    moveNoButton();

    if (state.noAttempts >= 6) {
      noButton.textContent = "NÃO 😌";
      noButton.style.opacity = "0.55";
    }
  }

  // Desktop: foge quando o mouse chega.
  noButton.addEventListener("pointerenter", rejectAttempt);

  // Celular: foge quando tentam tocar.
  noButton.addEventListener("pointerdown", rejectAttempt);

  document.getElementById("yesButton").addEventListener("click", () => {
    showScreen("date");
  });

  // Data e horário.
  const dateInput = document.getElementById("dateInput");
  const timeInput = document.getElementById("timeInput");
  const dateError = document.getElementById("dateError");

  document.getElementById("dateNext").addEventListener("click", () => {
    if (!dateInput.value || !timeInput.value) {
      dateError.textContent = "Escolha a data e o horário primeiro 😉";
      return;
    }

    dateError.textContent = "";
    state.date = dateInput.value;
    state.time = timeInput.value;

    showScreen("food");
  });

  // Escolha de comida.
  const foodButtons = [...document.querySelectorAll("#foodChoices .choice")];

  foodButtons.forEach((button) => {
    button.addEventListener("click", () => {
      foodButtons.forEach((item) => item.classList.remove("selected"));
      button.classList.add("selected");
      state.food = button.dataset.value;
    });
  });

  document.getElementById("foodNext").addEventListener("click", () => {
    if (!state.food) {
      window.alert("Escolha uma opção primeiro 😉");
      return;
    }

    const parts = state.date.split("-");
    const formattedDate =
      parts.length === 3
        ? `${parts[2]}/${parts[1]}/${parts[0]}`
        : state.date;

    document.getElementById("summary").innerHTML = `
      <strong>📅 Data:</strong> ${formattedDate}<br>
      <strong>🕐 Horário:</strong> ${state.time}<br>
      <strong>🍴 Escolha:</strong> ${state.food}<br>
      <strong>❤️ Status:</strong> Date confirmado
    `;

    showScreen("final");
  });

  // Reiniciar.
  document.getElementById("restart").addEventListener("click", () => {
    state.noAttempts = 0;
    state.date = "";
    state.time = "";
    state.food = "";

    dateInput.value = "";
    timeInput.value = "";
    dateError.textContent = "";
    reaction.textContent = "";
    face.textContent = "🥺";

    noButton.textContent = "NÃO";
    noButton.style.opacity = "1";
    noButton.style.left = "";
    noButton.style.top = "";
    noButton.style.right = "";

    foodButtons.forEach((button) => {
      button.classList.remove("selected");
    });

    showScreen("landing");
  });
})();
